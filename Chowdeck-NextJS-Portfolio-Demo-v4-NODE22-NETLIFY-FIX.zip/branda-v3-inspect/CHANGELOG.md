# Upgrade notes

## 1.0.0 — Next.js portfolio adaptation
- Migrated the original multi-page static prototype to Next.js App Router routes.
- Preserved the original purple/black visual direction, food cards, hero, categories, reviews and mobile drawer.
- Added typed product data, searchable/filterable catalogue, product detail routes and per-product metadata.
- Added localStorage-backed React cart state and demo checkout warning.
- Added Product JSON-LD on product detail pages and blocked indexing for the portfolio demo.
- Kept clear prototype disclaimers; no real payment, login, delivery, inventory or production API is claimed.
## Version 4 — Netlify Node compatibility
- Pin Netlify builds to Node.js 22 LTS via `.nvmrc` and `netlify.toml`.
- Declare supported Node range in `package.json` (>=20.9.0 <23).
- Preserve the existing storefront design and Version 3 lint fixes.
