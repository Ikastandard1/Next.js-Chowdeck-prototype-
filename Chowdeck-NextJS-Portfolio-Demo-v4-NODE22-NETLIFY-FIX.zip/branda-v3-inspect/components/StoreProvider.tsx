'use client';
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { ReactNode } from 'react';
import { foods, type Food } from '@/lib/foods';
type Store = { cart: Food[]; add:(id:number)=>void; remove:(index:number)=>void; clear:()=>void; count:number; toast:string };
const StoreContext=createContext<Store | null>(null);
export function StoreProvider({children}:{children:ReactNode}) {
 const [cart,setCart]=useState<Food[]>([]); const [toast,setToast]=useState('');
 useEffect(()=>{try{const saved=localStorage.getItem('chowdeckCart'); if(saved){const parsed=JSON.parse(saved); if(Array.isArray(parsed)){const savedItems=parsed.filter((item:unknown):item is {id:number}=>typeof item==='object'&&item!==null&&'id' in item&&typeof item.id==='number');setCart(savedItems.map(item=>foods.find(food=>food.id===item.id)).filter((food):food is Food=>Boolean(food)));}}}catch{}},[]);
 useEffect(()=>{try{localStorage.setItem('chowdeckCart',JSON.stringify(cart));}catch{}},[cart]);
 const add=useCallback((id:number)=>{const food=foods.find(f=>f.id===id);if(!food)return;setCart(c=>[...c,food]);setToast(`${food.name} added to cart`);setTimeout(()=>setToast(''),2200)},[]);
 const remove=useCallback((index:number)=>setCart(c=>c.filter((_,i)=>i!==index)),[]); const clear=useCallback(()=>setCart([]),[]);
 const value=useMemo(()=>({cart,add,remove,clear,count:cart.length,toast}),[cart,add,remove,clear,toast]);
 return <StoreContext.Provider value={value}>{children}{toast&&<div className="toast show" role="status">{toast}</div>}</StoreContext.Provider>;
}
export function useStore(){const v=useContext(StoreContext);if(!v)throw new Error('useStore must be used inside StoreProvider');return v;}
