'use client';
import { useStore } from './StoreProvider';
export default function AddToCartButton({id}:{id:number}){const {add}=useStore();return <button className="primary" onClick={()=>add(id)}>Add to cart <span>+</span></button>}
