'use client';
import Link from 'next/link';
import Image from 'next/image';
import { money, type Food } from '@/lib/foods';
import { useStore } from './StoreProvider';
export default function FoodCard({food}:{food:Food}){const {add}=useStore();return <article className="food-card"><Link href={`/product/${food.id}`} className="food-image"><Image src={food.img} alt={food.name} width={900} height={650} sizes="(max-width:650px) 48vw, (max-width:1000px) 48vw, 24vw" loading="lazy"/><span className="food-tag">Popular</span></Link><div className="food-info"><span className="restaurant">{food.restaurant}</span><h3>{food.name}</h3><p>{food.desc}</p><div className="food-bottom"><strong>{money(food.price)}</strong><button className="add-btn" onClick={()=>add(food.id)} aria-label={`Add ${food.name} to cart`}>+</button></div></div></article>}
