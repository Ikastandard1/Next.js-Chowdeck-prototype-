export type Food = { id:number; name:string; desc:string; price:number; cat:string; restaurant:string; img:string };
export const foods: Food[] = [
{id:1,name:'Smoky Chicken Burger',desc:'Double patty · Crispy chicken',price:4800,cat:'burgers',restaurant:'The Burger Room',img:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=900&q=85'},
{id:2,name:'Pepperoni Pizza',desc:'Cheese · Pepperoni · Basil',price:6500,cat:'pizza',restaurant:'Crust & Co.',img:'https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=900&q=85'},
{id:3,name:'Jollof Rice Special',desc:'Party jollof · Chicken · Plantain',price:4200,cat:'rice',restaurant:'Mama’s Kitchen',img:'https://images.unsplash.com/photo-1604329760661-e71dc83f8f26?auto=format&fit=crop&w=900&q=85'},
{id:4,name:'Crispy Fried Chicken',desc:'Golden chicken · Signature spice',price:5500,cat:'chicken',restaurant:'Crispy House',img:'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=900&q=85'},
{id:5,name:'Creamy Pasta',desc:'Cream sauce · Herbs · Parmesan',price:5200,cat:'rice',restaurant:'Pasta Place',img:'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?auto=format&fit=crop&w=900&q=85'},
{id:6,name:'Berry Fizz',desc:'Sparkling berries · Fresh mint',price:2200,cat:'drinks',restaurant:'The Sip Bar',img:'https://images.unsplash.com/photo-1544145945-f90425340c7e?auto=format&fit=crop&w=900&q=85'},
{id:7,name:'Loaded Fries',desc:'Crispy fries · Sauce · Beef',price:3500,cat:'chicken',restaurant:'Street Bites',img:'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=900&q=85'},
{id:8,name:'Chocolate Cake',desc:'Soft chocolate · Ganache',price:3000,cat:'dessert',restaurant:'Sweet Crumbs',img:'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=900&q=85'}
];
export const money=(n:number)=>'₦'+Number(n).toLocaleString('en-NG');
