import type { Metadata } from 'next';
import './globals.css';
import { StoreProvider } from '@/components/StoreProvider';
import SiteShell from '@/components/SiteShell';
export const metadata: Metadata = { title:{default:'Chowdeck-inspired Food Ordering Demo',template:'%s | Chowdeck Demo'}, description:'A portfolio demonstration of a responsive food ordering experience with discovery, product details and a local demo cart.', metadataBase:new URL('https://example.com'), robots:{index:false,follow:false} };
export default function RootLayout({children}:{children:React.ReactNode}) { return <html lang="en"><body><StoreProvider><SiteShell>{children}</SiteShell></StoreProvider></body></html>; }
